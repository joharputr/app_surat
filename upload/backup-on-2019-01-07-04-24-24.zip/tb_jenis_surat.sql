#
# TABLE STRUCTURE FOR: gambar
#

DROP TABLE IF EXISTS gambar;

CREATE TABLE `gambar` (
  `id_gambar` int(11) NOT NULL AUTO_INCREMENT,
  `gambar` varchar(255) NOT NULL,
  `surat_id` int(10) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `tgl_surat` date NOT NULL,
  PRIMARY KEY (`id_gambar`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO gambar (`id_gambar`, `gambar`, `surat_id`, `nama`, `tgl_surat`) VALUES ('1', '1.jpg', '0', 'Celanamu', '2019-01-05');
INSERT INTO gambar (`id_gambar`, `gambar`, `surat_id`, `nama`, `tgl_surat`) VALUES ('2', '2.gif', '1', 'Hayabusa', '2019-01-11');


#
# TABLE STRUCTURE FOR: login
#

DROP TABLE IF EXISTS login;

CREATE TABLE `login` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;

INSERT INTO login (`id_user`, `username`, `password`, `nama`) VALUES ('1', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Administrator');
INSERT INTO login (`id_user`, `username`, `password`, `nama`) VALUES ('15', 'bmkg', 'bmkg', 'bmkg');
INSERT INTO login (`id_user`, `username`, `password`, `nama`) VALUES ('16', 'haya', '12345', 'Hayabusa');


#
# TABLE STRUCTURE FOR: tb_jenis_surat
#

DROP TABLE IF EXISTS tb_jenis_surat;

CREATE TABLE `tb_jenis_surat` (
  `surat_id` int(11) NOT NULL AUTO_INCREMENT,
  `no_agenda` varchar(255) NOT NULL,
  `tgl_terima` date NOT NULL,
  `kode_arsip` varchar(255) NOT NULL,
  `no_surat` varchar(255) NOT NULL,
  `tgl_surat` date NOT NULL,
  `pengirim` varchar(25) NOT NULL,
  `perihal` text NOT NULL,
  `lampiran` varchar(255) NOT NULL,
  `sifat_surat` varchar(255) NOT NULL,
  `penjabat_disposisi` varchar(255) NOT NULL,
  `disposisi` varchar(255) NOT NULL,
  `asli_copy` varchar(255) NOT NULL,
  `informasi_disposisi` text NOT NULL,
  `gambar` varchar(255) NOT NULL,
  PRIMARY KEY (`surat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO tb_jenis_surat (`surat_id`, `no_agenda`, `tgl_terima`, `kode_arsip`, `no_surat`, `tgl_surat`, `pengirim`, `perihal`, `lampiran`, `sifat_surat`, `penjabat_disposisi`, `disposisi`, `asli_copy`, `informasi_disposisi`, `gambar`) VALUES ('8', '09', '2018-12-19', 'PR.203', 'PMSC-KSO-API-NYIA-MTG-0467', '2019-02-06', 'PMSC NYIA', 'Undangan Rapat Navigasi Penerbangan', 'Satu bendel 2', 'Sangat Penting', 'Kasklim Mlati', 'Tata Usaha', 'surat asli', 'hahahaa           hAahaha                                   ', '8.jpg');
INSERT INTO tb_jenis_surat (`surat_id`, `no_agenda`, `tgl_terima`, `kode_arsip`, `no_surat`, `tgl_surat`, `pengirim`, `perihal`, `lampiran`, `sifat_surat`, `penjabat_disposisi`, `disposisi`, `asli_copy`, `informasi_disposisi`, `gambar`) VALUES ('9', '002', '2018-12-18', 'PR.202', 'KP.003/939/SMN/XII/2018', '2018-12-02', 'Kasklim Wates', 'Undangan Kumpulan Rutin Tahunan', '-', 'Segera', 'Kasklim Mlati', '0', 'surat copy', '', '');
INSERT INTO tb_jenis_surat (`surat_id`, `no_agenda`, `tgl_terima`, `kode_arsip`, `no_surat`, `tgl_surat`, `pengirim`, `perihal`, `lampiran`, `sifat_surat`, `penjabat_disposisi`, `disposisi`, `asli_copy`, `informasi_disposisi`, `gambar`) VALUES ('10', '003', '2018-12-28', 'UM.001', 'BMKG.001/19/12/2018', '2018-12-15', 'Kasklim Wates 2', 'Surat Keputusan Ketua BMKG hahaha', 'Satu bendel', 'Penting', 'Ketua BMKG hihi', '0', 'surat asli', '  ', '');
INSERT INTO tb_jenis_surat (`surat_id`, `no_agenda`, `tgl_terima`, `kode_arsip`, `no_surat`, `tgl_surat`, `pengirim`, `perihal`, `lampiran`, `sifat_surat`, `penjabat_disposisi`, `disposisi`, `asli_copy`, `informasi_disposisi`, `gambar`) VALUES ('11', '005', '2019-01-17', 'PR.203', 'KP.003/939/SMN/XII/2018', '2019-01-03', 'PMSC NYIA', 'Undangan Rapat Navigasi Penerbangan', '-', 'Rahasia', 'Kasklim Mlati', 'Tata Usaha, Kapok Datin, Bendahara Pengeluaran', 'surat copy', '      ', '');


#
# TABLE STRUCTURE FOR: tb_surat_keluar
#

DROP TABLE IF EXISTS tb_surat_keluar;

CREATE TABLE `tb_surat_keluar` (
  `surat_id` int(11) NOT NULL AUTO_INCREMENT,
  `no_agenda` varchar(255) NOT NULL,
  `kode_arsip` varchar(255) NOT NULL,
  `tgl_surat` date NOT NULL,
  `no_surat` varchar(255) NOT NULL,
  `tujuan` varchar(255) NOT NULL,
  `perihal` text NOT NULL,
  `asli_copy` varchar(255) NOT NULL,
  `keterangan` text NOT NULL,
  `gambar` varchar(255) NOT NULL,
  PRIMARY KEY (`surat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('8', '001', 'PR.202', '2019-01-03', 'KP.003/939/SMN/XII/2018', 'Anang Ariane', 'Pemberitahuan Masa Persiapan Pensiun a.n. Elvera L', 'surat asli', '        ', '8.jpg');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('9', '123', 'KP.019', '2019-01-11', 'PMSC-KSO-API-NYIA-MTG-0467', 'Jakarta', 'bimbingan', 'surat copy', '', '');


