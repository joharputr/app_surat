#
# TABLE STRUCTURE FOR: buat_surat
#

DROP TABLE IF EXISTS buat_surat;

CREATE TABLE `buat_surat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama1` varchar(255) NOT NULL,
  `nama2` varchar(255) NOT NULL,
  `nip1` varchar(255) NOT NULL,
  `nip2` varchar(255) NOT NULL,
  `pangkat1` varchar(255) NOT NULL,
  `jabatan1` varchar(255) NOT NULL,
  `pangkat2` varchar(255) NOT NULL,
  `jabatan2` varchar(255) NOT NULL,
  `tugas` varchar(255) NOT NULL,
  `unit` varchar(255) NOT NULL,
  `waktu` varchar(255) NOT NULL,
  `lokasi` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO buat_surat (`id`, `nama1`, `nama2`, `nip1`, `nip2`, `pangkat1`, `jabatan1`, `pangkat2`, `jabatan2`, `tugas`, `unit`, `waktu`, `lokasi`, `tanggal`, `keterangan`) VALUES ('7', 'Agus Sudaryatno, S.Kom, MM', 'Anang Ariane, S.Si, M.Sc', '196101201980031001 ', '198706112008121001', 'Pembina/IV.a', 'Kepala Stasiun Klimatologi Kelas IV Mlati', 'Penata Muda/III.a', 'PMG Pertama', 'Menghadiri Apel Penutupan Posko Angkutan Udara Natal 2018 dan Tahun Baru 2019', 'Stasiun Klimatologi Kelas IV Mlati', '08.00 WIB s.d. selesai', 'Lapangan NDB PT. Angkasa Pura I (Persero)', '2019-01-10', '');


#
# TABLE STRUCTURE FOR: gambar
#

DROP TABLE IF EXISTS gambar;

CREATE TABLE `gambar` (
  `id_gambar` int(11) NOT NULL AUTO_INCREMENT,
  `gambar` varchar(255) NOT NULL,
  `surat_id` int(10) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `tgl_surat` date NOT NULL,
  PRIMARY KEY (`id_gambar`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO gambar (`id_gambar`, `gambar`, `surat_id`, `nama`, `tgl_surat`) VALUES ('1', '1.jpg', '0', 'Celanamu', '2019-01-05');
INSERT INTO gambar (`id_gambar`, `gambar`, `surat_id`, `nama`, `tgl_surat`) VALUES ('2', '2.gif', '1', 'Hayabusa', '2019-01-11');
INSERT INTO gambar (`id_gambar`, `gambar`, `surat_id`, `nama`, `tgl_surat`) VALUES ('3', 'Anitoki_Gamers__06_720p_2F55F0B4_0.mkv_snapshot_23_.47_2017_.08_.20_09_.20_.04_.jpg', '1', '', '0000-00-00');


#
# TABLE STRUCTURE FOR: login
#

DROP TABLE IF EXISTS login;

CREATE TABLE `login` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;

INSERT INTO login (`id_user`, `username`, `password`, `nama`) VALUES ('1', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Administrator');
INSERT INTO login (`id_user`, `username`, `password`, `nama`) VALUES ('15', 'bmkg', 'bmkg', 'bmkg');
INSERT INTO login (`id_user`, `username`, `password`, `nama`) VALUES ('16', 'haya', '12345', 'Hayabusa');


#
# TABLE STRUCTURE FOR: tb_jenis_surat
#

DROP TABLE IF EXISTS tb_jenis_surat;

CREATE TABLE `tb_jenis_surat` (
  `surat_id` int(11) NOT NULL AUTO_INCREMENT,
  `no_agenda` varchar(255) NOT NULL,
  `tgl_terima` date NOT NULL,
  `kode_arsip` varchar(255) NOT NULL,
  `no_surat` varchar(255) NOT NULL,
  `tgl_surat` date NOT NULL,
  `pengirim` varchar(25) NOT NULL,
  `perihal` text NOT NULL,
  `lampiran` varchar(255) NOT NULL,
  `sifat_surat` varchar(255) NOT NULL,
  `penjabat_disposisi` varchar(255) NOT NULL,
  `disposisi` varchar(255) NOT NULL,
  `asli_copy` varchar(255) NOT NULL,
  `informasi_disposisi` text NOT NULL,
  `gambar` varchar(255) NOT NULL,
  PRIMARY KEY (`surat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO tb_jenis_surat (`surat_id`, `no_agenda`, `tgl_terima`, `kode_arsip`, `no_surat`, `tgl_surat`, `pengirim`, `perihal`, `lampiran`, `sifat_surat`, `penjabat_disposisi`, `disposisi`, `asli_copy`, `informasi_disposisi`, `gambar`) VALUES ('1', '001', '2019-01-07', 'PR.203', 'PMSC-KSO-API-NYIA-MTG-0467', '2019-01-23', 'PMSC NYIA', 'Undangan Rapat Navigasi Penerbangan', '-', 'Penting', 'Kasklim Mlati', '0', 'surat asli', '', '');


#
# TABLE STRUCTURE FOR: tb_surat_keluar
#

DROP TABLE IF EXISTS tb_surat_keluar;

CREATE TABLE `tb_surat_keluar` (
  `surat_id` int(11) NOT NULL AUTO_INCREMENT,
  `no_agenda` varchar(255) NOT NULL,
  `kode_arsip` varchar(255) NOT NULL,
  `tgl_surat` date NOT NULL,
  `no_surat` varchar(255) NOT NULL,
  `tujuan` varchar(255) NOT NULL,
  `perihal` text NOT NULL,
  `asli_copy` varchar(255) NOT NULL,
  `keterangan` text NOT NULL,
  `gambar` varchar(255) NOT NULL,
  PRIMARY KEY (`surat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('1', '001', 'KP.019', '2019-01-17', 'PMSC-KSO-API-NYIA-MTG-0467', 'Anang Ariane', 'bimbingan', 'surat asli', '', '');


