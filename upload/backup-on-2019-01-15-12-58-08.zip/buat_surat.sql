#
# TABLE STRUCTURE FOR: buat_surat
#

DROP TABLE IF EXISTS buat_surat;

CREATE TABLE `buat_surat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no_surat` varchar(255) NOT NULL,
  `nama1` varchar(255) NOT NULL,
  `nama2` varchar(255) NOT NULL,
  `nip1` varchar(255) NOT NULL,
  `nip2` varchar(255) NOT NULL,
  `pangkat1` varchar(255) NOT NULL,
  `jabatan1` varchar(255) NOT NULL,
  `pangkat2` varchar(255) NOT NULL,
  `jabatan2` varchar(255) NOT NULL,
  `tugas` varchar(255) NOT NULL,
  `unit` varchar(255) NOT NULL,
  `waktu` varchar(255) NOT NULL,
  `lokasi` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `plh` varchar(255) NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO buat_surat (`id`, `no_surat`, `nama1`, `nama2`, `nip1`, `nip2`, `pangkat1`, `jabatan1`, `pangkat2`, `jabatan2`, `tugas`, `unit`, `waktu`, `lokasi`, `tanggal`, `plh`, `keterangan`) VALUES ('7', '', 'Agus Sudaryatno, S.Kom, MM', 'Anang Ariane, S.Si, M.Sc', '196101201980031001 ', '198706112008121001', 'Pembina/IV.a', 'Kepala Stasiun Klimatologi Kelas IV Mlati', 'Penata Muda/III.a', 'PMG Pertama', 'Menghadiri Apel Penutupan Posko Angkutan Udara Natal 2018 dan Tahun Baru 2019', 'Stasiun Klimatologi Kelas IV Mlati', '08.00 WIB s.d. selesai', 'Lapangan NDB PT. Angkasa Pura I (Persero)', '2019-01-10', '', '');
INSERT INTO buat_surat (`id`, `no_surat`, `nama1`, `nama2`, `nip1`, `nip2`, `pangkat1`, `jabatan1`, `pangkat2`, `jabatan2`, `tugas`, `unit`, `waktu`, `lokasi`, `tanggal`, `plh`, `keterangan`) VALUES ('8', '', 'Agus Sudaryatno, S.Kom, MM', 'Desy Rumayanti Setyo, A.Md', '196101201980031001 ', '198312142008122001', 'Pembina/IV.a', 'Kepala Stasiun Klimatologi Kelas IV Mlati', 'Penata Muda/III.a', 'Pengadministrasian Umum', '', 'Stasiun Klimatologi Kelas IV Mlati', '', '', '0000-00-00', '', 'telah melaksanakan Magang/PKL (Praktek Kerja Lapangan) Pengelolaan Arsip Dinamis (Arsip Aktif) di Kantor Stasiun Klimatologi Kelas IV Mlati dan Arsip Inaktif di Kantor Stasiun Geofisika Kelas I Yogyakarta.');
INSERT INTO buat_surat (`id`, `no_surat`, `nama1`, `nama2`, `nip1`, `nip2`, `pangkat1`, `jabatan1`, `pangkat2`, `jabatan2`, `tugas`, `unit`, `waktu`, `lokasi`, `tanggal`, `plh`, `keterangan`) VALUES ('9', '', 'Agus Sudaryatno, S.Kom, MM', 'Desy Rumayanti Setyo, A.Md', '196101201980031001 ', '198312142008122001', 'Pembina/IV.a', 'Kepala Stasiun Klimatologi Kelas IV Mlati', 'Penata Muda/III.a', 'Pengadministrasian Umum', 'Menghadiri Apel Penutupan Posko Angkutan Udara Natal 2018 dan Tahun Baru 2019', 'Stasiun Klimatologi Kelas IV Mlati', '08.00 WIB s.d. selesai', 'Lapangan NDB PT. Angkasa Pura I (Persero)', '2019-01-25', '', 'coba aja');
INSERT INTO buat_surat (`id`, `no_surat`, `nama1`, `nama2`, `nip1`, `nip2`, `pangkat1`, `jabatan1`, `pangkat2`, `jabatan2`, `tugas`, `unit`, `waktu`, `lokasi`, `tanggal`, `plh`, `keterangan`) VALUES ('10', '', 'Agus Sudaryatno, S.Kom, MM', 'Anang Ariane, S.Si, M.Sc', '196101201980031001 ', '198706112008121001', 'Pembina/IV.a', 'Kepala Stasiun Klimatologi Kelas IV Mlati', 'Penata Muda/III.a', 'Pengadministrasian Umum', 'Menghadiri Apel Penutupan Posko Angkutan Udara Natal 2018 dan Tahun Baru 2019', 'Stasiun Klimatologi Kelas IV Mlati', '08.00 WIB s.d. selesai', 'Lapangan NDB PT. Angkasa Pura I (Persero)', '2019-01-11', '', 'mencoba');
INSERT INTO buat_surat (`id`, `no_surat`, `nama1`, `nama2`, `nip1`, `nip2`, `pangkat1`, `jabatan1`, `pangkat2`, `jabatan2`, `tugas`, `unit`, `waktu`, `lokasi`, `tanggal`, `plh`, `keterangan`) VALUES ('11', 'KP.003/939/SMN/XII/2018', 'Agus Sudaryatno, S.Kom, MM', 'Desy Rumayanti Setyo, A.Md', '196101201980031001 ', '198312142008122001', 'Pembina/IV.a', 'Kepala Stasiun Klimatologi Kelas IV Mlati', 'Penata Muda/III.a', 'Pengadministrasian Umum', 'Menghadiri Apel Penutupan Posko Angkutan Udara Natal 2018 dan Tahun Baru 2019', 'Stasiun Klimatologi Kelas IV Mlati', '08.00 WIB s.d. selesai', 'Lapangan NDB PT. Angkasa Pura I (Persero)', '2019-01-10', 'PLH. Kepala,', '');


#
# TABLE STRUCTURE FOR: gambar
#

DROP TABLE IF EXISTS gambar;

CREATE TABLE `gambar` (
  `id_gambar` int(11) NOT NULL AUTO_INCREMENT,
  `gambar` varchar(255) NOT NULL,
  `surat_id` int(10) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `tgl_surat` date NOT NULL,
  PRIMARY KEY (`id_gambar`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO gambar (`id_gambar`, `gambar`, `surat_id`, `nama`, `tgl_surat`) VALUES ('1', '1.jpg', '0', 'Celanamu', '2019-01-05');
INSERT INTO gambar (`id_gambar`, `gambar`, `surat_id`, `nama`, `tgl_surat`) VALUES ('2', '2.gif', '1', 'Hayabusa', '2019-01-11');
INSERT INTO gambar (`id_gambar`, `gambar`, `surat_id`, `nama`, `tgl_surat`) VALUES ('3', 'Anitoki_Gamers__06_720p_2F55F0B4_0.mkv_snapshot_23_.47_2017_.08_.20_09_.20_.04_.jpg', '1', '', '0000-00-00');


#
# TABLE STRUCTURE FOR: login
#

DROP TABLE IF EXISTS login;

CREATE TABLE `login` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;

INSERT INTO login (`id_user`, `username`, `password`, `nama`) VALUES ('1', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Administrator');
INSERT INTO login (`id_user`, `username`, `password`, `nama`) VALUES ('15', 'bmkg', 'bmkg', 'bmkg');
INSERT INTO login (`id_user`, `username`, `password`, `nama`) VALUES ('16', 'haya', '12345', 'Hayabusa');


#
# TABLE STRUCTURE FOR: tb_jenis_surat
#

DROP TABLE IF EXISTS tb_jenis_surat;

CREATE TABLE `tb_jenis_surat` (
  `surat_id` int(11) NOT NULL AUTO_INCREMENT,
  `no_agenda` varchar(255) NOT NULL,
  `tgl_terima` date NOT NULL,
  `kode_arsip` varchar(255) NOT NULL,
  `kode_arsip2` varchar(255) NOT NULL,
  `no_surat` varchar(255) NOT NULL,
  `tgl_surat` date NOT NULL,
  `pengirim` varchar(25) NOT NULL,
  `perihal` text NOT NULL,
  `lampiran` varchar(255) NOT NULL,
  `sifat_surat` varchar(255) NOT NULL,
  `penjabat_disposisi` varchar(255) NOT NULL,
  `disposisi` varchar(255) NOT NULL,
  `asli_copy` varchar(255) NOT NULL,
  `informasi_disposisi` text NOT NULL,
  `gambar` varchar(255) NOT NULL,
  PRIMARY KEY (`surat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO tb_jenis_surat (`surat_id`, `no_agenda`, `tgl_terima`, `kode_arsip`, `kode_arsip2`, `no_surat`, `tgl_surat`, `pengirim`, `perihal`, `lampiran`, `sifat_surat`, `penjabat_disposisi`, `disposisi`, `asli_copy`, `informasi_disposisi`, `gambar`) VALUES ('1', '001', '2019-01-07', '', 'p001', 'PMSC-KSO-API-NYIA-MTG-0467', '2019-01-23', 'PMSC NYIA', 'Undangan Rapat Navigasi Penerbangan', '-', 'Penting', 'Kasklim Mlati', 'Tata Usaha', 'surat asli', '  ', 'default.jpg');
INSERT INTO tb_jenis_surat (`surat_id`, `no_agenda`, `tgl_terima`, `kode_arsip`, `kode_arsip2`, `no_surat`, `tgl_surat`, `pengirim`, `perihal`, `lampiran`, `sifat_surat`, `penjabat_disposisi`, `disposisi`, `asli_copy`, `informasi_disposisi`, `gambar`) VALUES ('2', '001', '2019-01-07', 'UM.202', '', '005/001', '2019-01-08', 'johar', 'Undangan Rapat Navigasi Penerbangan', '-', 'Biasa', 'Kasklim Mlati', 'Tata Usaha, Kapok Datin, Kapok Obs', 'surat asli', '', '2.pdf');


#
# TABLE STRUCTURE FOR: tb_surat_keluar
#

DROP TABLE IF EXISTS tb_surat_keluar;

CREATE TABLE `tb_surat_keluar` (
  `surat_id` int(11) NOT NULL AUTO_INCREMENT,
  `no_agenda` varchar(255) NOT NULL,
  `kode_arsip` varchar(255) NOT NULL,
  `kode_arsip2` varchar(255) NOT NULL,
  `tgl_surat` date NOT NULL,
  `no_surat` varchar(255) NOT NULL,
  `tujuan` varchar(255) NOT NULL,
  `perihal` text NOT NULL,
  `asli_copy` varchar(255) NOT NULL,
  `keterangan` text NOT NULL,
  `gambar` varchar(255) NOT NULL,
  PRIMARY KEY (`surat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `kode_arsip2`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('1', '001', 'KP.003', '', '2019-01-17', 'KP.003/939/SMN/XII/2018', 'Anang Ariane', 'bimbingan', 'surat asli', '  ', 'default.jpg');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `kode_arsip2`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('2', '001', 'PR.202', '', '2019-01-11', 'KP.003/939/SMN/XII/2018', 'Anang Ariane', 'bimbingan', 'surat copy', '  ', '2.pdf');


