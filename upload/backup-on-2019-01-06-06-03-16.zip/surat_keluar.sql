#
# TABLE STRUCTURE FOR: admin
#

DROP TABLE IF EXISTS admin;

CREATE TABLE `admin` (
  `id` int(255) NOT NULL,
  `username` varchar(244) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO admin (`id`, `username`, `password`) VALUES ('1', 'tes', 'tes');
INSERT INTO admin (`id`, `username`, `password`) VALUES ('2', 'admin', '12345');


#
# TABLE STRUCTURE FOR: gambar
#

DROP TABLE IF EXISTS gambar;

CREATE TABLE `gambar` (
  `gambar` varchar(255) NOT NULL,
  `id_gambar` int(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `tgl_surat` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO gambar (`gambar`, `id_gambar`, `nama`, `tgl_surat`) VALUES ('2.png', '2', 'sdsda', '2019-01-16');
INSERT INTO gambar (`gambar`, `id_gambar`, `nama`, `tgl_surat`) VALUES ('3.png', '3', 'sds', '2018-12-14');


#
# TABLE STRUCTURE FOR: login
#

DROP TABLE IF EXISTS login;

CREATE TABLE `login` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4;

INSERT INTO login (`id_user`, `username`, `password`, `nama`) VALUES ('27', 'bmkg', 'bmkg', 'bmkg');
INSERT INTO login (`id_user`, `username`, `password`, `nama`) VALUES ('28', 'maria', '123', 'maria');
INSERT INTO login (`id_user`, `username`, `password`, `nama`) VALUES ('29', 'mario _mandzukic', '123', 'Mario Mandzukic');


#
# TABLE STRUCTURE FOR: tb_jenis_surat
#

DROP TABLE IF EXISTS tb_jenis_surat;

CREATE TABLE `tb_jenis_surat` (
  `surat_id` int(5) NOT NULL AUTO_INCREMENT,
  `jenis_surat` char(20) NOT NULL,
  `no_agenda` varchar(5) NOT NULL,
  `tgl_terima` date NOT NULL,
  `kode_arsip` varchar(255) NOT NULL,
  `no_surat` int(20) NOT NULL,
  `tgl_surat` date NOT NULL,
  `pengirim` varchar(25) NOT NULL,
  `perihal` varchar(255) NOT NULL,
  `lampiran` varchar(255) NOT NULL,
  `sifat_surat` varchar(255) NOT NULL,
  `penjabat_disposisi` varchar(255) NOT NULL,
  `disposisi` varchar(255) NOT NULL,
  `asli_copy` varchar(255) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `informasi_disposisi` varchar(255) NOT NULL,
  PRIMARY KEY (`surat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=latin1;

INSERT INTO tb_jenis_surat (`surat_id`, `jenis_surat`, `no_agenda`, `tgl_terima`, `kode_arsip`, `no_surat`, `tgl_surat`, `pengirim`, `perihal`, `lampiran`, `sifat_surat`, `penjabat_disposisi`, `disposisi`, `asli_copy`, `gambar`, `informasi_disposisi`) VALUES ('83', '', '11', '0000-00-00', '', '0', '0000-00-00', '', '', '', 'Biasa', '', 'Bendahara Penerimaan', 'surat asli', '83.pdf', '                                      ');
INSERT INTO tb_jenis_surat (`surat_id`, `jenis_surat`, `no_agenda`, `tgl_terima`, `kode_arsip`, `no_surat`, `tgl_surat`, `pengirim`, `perihal`, `lampiran`, `sifat_surat`, `penjabat_disposisi`, `disposisi`, `asli_copy`, `gambar`, `informasi_disposisi`) VALUES ('85', '', '23', '2019-02-08', '', '12', '2019-01-08', 'Johar', 'qw', 'w', 'Biasa', 'q', '0', 'surat asli', 'default.jpg', '         sd         ');
INSERT INTO tb_jenis_surat (`surat_id`, `jenis_surat`, `no_agenda`, `tgl_terima`, `kode_arsip`, `no_surat`, `tgl_surat`, `pengirim`, `perihal`, `lampiran`, `sifat_surat`, `penjabat_disposisi`, `disposisi`, `asli_copy`, `gambar`, `informasi_disposisi`) VALUES ('86', '', '11', '1900-12-06', 'KP.012', '1', '1900-12-01', 'ddsd', 'bimbingan', 'satu bendel', 'Segera', 'dekan', 'Kapok Datin, Bendahara Penerimaan', 'surat copy', '86.jpg', '  r');
INSERT INTO tb_jenis_surat (`surat_id`, `jenis_surat`, `no_agenda`, `tgl_terima`, `kode_arsip`, `no_surat`, `tgl_surat`, `pengirim`, `perihal`, `lampiran`, `sifat_surat`, `penjabat_disposisi`, `disposisi`, `asli_copy`, `gambar`, `informasi_disposisi`) VALUES ('87', '', '', '0000-00-00', '', '0', '0000-00-00', '', '', '', 'Biasa', '', '0', 'surat asli', '', '');


#
# TABLE STRUCTURE FOR: tb_surat_keluar
#

DROP TABLE IF EXISTS tb_surat_keluar;

CREATE TABLE `tb_surat_keluar` (
  `surat_id` int(5) NOT NULL AUTO_INCREMENT,
  `no_agenda` int(5) NOT NULL,
  `kode_arsip` varchar(255) NOT NULL,
  `tgl_surat` date NOT NULL,
  `no_surat` int(20) NOT NULL,
  `tujuan` varchar(255) NOT NULL,
  `perihal` varchar(255) NOT NULL,
  `asli_copy` varchar(255) NOT NULL,
  `keterangan` varchar(255) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  PRIMARY KEY (`surat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2346 DEFAULT CHARSET=latin1;

INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('2340', '567', 'SS.07', '2018-12-06', '101', 'Mahasiswa Kreatif', 'Percobaan Surat', 'surat asli', '  Karena percobaan dibuthuhkan  ', 'default.jpg');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('2341', '789', 'ps.123', '2018-11-30', '111', 'Apalah', 'Coba', 'surat copy', '  ansaff;,sa ajjsa ahafa  ', 'default.jpg');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('2342', '890', 'KK.45', '2018-12-01', '23', 'ya', 'begitulah', 'surat asli', '  jkhknaf akfs  ', 'default.jpg');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('2343', '111', 'UM.P06', '2018-12-29', '43434', 'Surabaya', 'bimbingan', 'surat asli', 'fffg', '');
INSERT INTO tb_surat_keluar (`surat_id`, `no_agenda`, `kode_arsip`, `tgl_surat`, `no_surat`, `tujuan`, `perihal`, `asli_copy`, `keterangan`, `gambar`) VALUES ('2344', '11', 'KU.102', '0000-12-14', '11', 'qw', 'qwq', 'surat asli', ' wq   ', 'default.jpg');


